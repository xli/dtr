require 'test/unit'
class ATestCase2 < Test::Unit::TestCase
  def test_succeeded
    assert true
  end
end

